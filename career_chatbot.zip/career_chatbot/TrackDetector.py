
from google import genai


API_KEY = "AIzaSyD0WjZFnrTQH5vSs8D4R1FMqkKHmzpanaE" 
client = genai.Client(api_key=API_KEY)


system_prompt = """
You are a professional programming career chatbot. Your tasks:

1. Read the user's description of skills, projects, or interests.
2. Determine the MOST SUITABLE programming track.
   - Use common tracks like Frontend, Backend, Fullstack, Mobile, Data, ML, DevOps, Security, Cloud, Game Dev, Embedded Systems, IoT, AI.
   - **If the user's skills indicate a different or new area not listed above, create a new track name that fits best.**
3. Explain clearly in simple, beginner-friendly language why this track is suitable.
4. Ask ONE follow-up question if the description is unclear or too short.
5. Provide a short roadmap for beginners.
6. Always respond clearly in English, using bullet points or numbered lists.
7. Never give advice outside programming fields.

Example response format:
- Track: Fullstack
- Reason: Python used for backend, project involves web interface → Fullstack
- Follow-up: Was Python mainly backend logic or just interface?
- Roadmap: Learn HTML/CSS, then Django/Flask, connect frontend with backend

Example for a new track:
- User: I work on quantum computing algorithms
- Bot:
    - Track: Quantum Computing
    - Reason: Projects involve quantum algorithms and computation beyond classical programming.
    - Roadmap: Learn linear algebra, basics of quantum mechanics, Qiskit, simulate quantum circuits.
"""


def get_track(user_input):
    """
    Sends user input + system prompt to Gemini and returns the response.
    """
    prompt = f"{system_prompt}\nUser: {user_input}"
    response = client.models.generate_content(
        model="gemini-2.5-flash", 
        contents=prompt
    )
    return response.text


def main():
    print(" Intelligent Track Detector")
    print("Type 'exit' to quit.\n")
    while True:
        user_input = input("User: ").strip()
        if user_input.lower() in ["exit", "quit"]:
            print("Goodbye!")
            break
        if not user_input:
            print("Bot: Please provide at least a few words about your skills or experience.\n")
            continue
        bot_response = get_track(user_input)
        print(f"\nBot:\n{bot_response}\n")

if __name__ == "__main__":
    main()
